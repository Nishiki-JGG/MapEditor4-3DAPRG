マップエディター 書き出しデータ (schemaVersion 3, tdj-map-editor/2026.10.19-r7)
roomId: 630a7645-08e8-4568-a95b-7d561175a64f
revision・書き出し日時・ファイルごとの SHA-256・contentHash は manifest.json にあります。

■ 座標（全ファイル共通。meta.json の coordinateSystem に機械可読で記載）
- 単位 m、Y が上、Unity の左手系。原点はテレインの角、y=0 は書き出した高さの最小値。
- グリッドは頂点 129x129、0.5m 間隔（Unity Terrain の解像度。エディター内部は 129x129・0.5m で、map.json だけがそれを使います）。RAW は行 r = z 方向、行0 が z=0。PNG は上端が z=64、下端が z=0（Unity のテクスチャと同じ）。
- 回転 rotY_deg / yawDeg は Unity の Euler Y（上から見て時計回りが正）。
- 高さの復元: y = 値/65535 × 11.8902。

■ ファイル
- heightmap_r16.raw / walk_floor_r16.raw : 地形の高さ / 歩く床の高さ（橋・階段・隠し通路）。同じ倍率。
- weights_0〜3.png : Terrain Layer の重み（草を含めて合計255）。順番は meta.json の groundBlend.layers。
- mask_0〜3.png    : 塗りの元データ（毒沼・溶岩などのゲーム判定用）。効果は groundTypes の effectId。
- holes.png        : 隠し通路がある場合だけ。地形の穴（0 = 穴、(解像度-1)² セル）。
- secret_passages_mesh.json : 隠し通路の床・壁・天井・ふた（穴と同じ形から作成。Unity 座標）。meta.secretPassages に輪郭・出入口・検査結果。route と width は目安。
- walkable.png     : 通行判定（離散値。補間しないでください）。meta.json の agentProfile の体格で計算。
- props.csv        : 小物の配置。instanceId は再書き出しでも変わりません。assetKey は asset_catalog.json の対応表。
- asset_catalog.json : 種類ごとの assetKey と、エディターが使う代理の当たり判定。編集してエディターに読み込めます。
- meta.json        : 座標仕様、開始地点、出入口・敵/宝箱候補・禁止範囲、階層移動（魔法陣・上り/下り階段 = floorLinks）、橋・階段・滝、水、天候、霧。
- validation.json  : 書き出し時の検証結果（エラー 0 / 警告 0）。
- map.json         : エディター用の元データ（座標はエディター内部の中心基準。Unity では使いません）。
- manifest.json    : exporterVersion、revision、exportedAt、各ファイルの大きさと SHA-256、contentHash。

■ 変更の検出（manifest.json）
- contentHash = 「exporterVersion の1行」＋「ファイル名 SHA-256 の行（files の順）」を UTF-8 にした SHA-256。manifest.json 自身は含みません。
- exportedAt と revision は manifest.json にだけ書くので、編集せずに書き出し直すと contentHash は同じです。RAW・画像・カタログ・出力ロジック（exporterVersion）が変われば変わります。
- revision は contentHash が前回の書き出しと変わったときだけ 1 増えます。

■ Prefab の向き（asset_catalog.json の frame）
- Prefab のローカル +Z = プレイヤーが入っていく向き、-Z = 近づいてくる側。回転は yawDeg + yawOffsetDeg。
- 当たり判定（radius / offsets / solid）も同じローカル座標。エディター内部のローカル座標とは z の符号だけが違います。
